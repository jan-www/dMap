export default {
  at: {
    select: {
      placeholder: 'Selecione',
      notFoundText: 'Nenhum dado correspondente'
    },
    modal: {
      okText: 'OK',
      cancelText: 'Cancelar'
    },
    pagination: {
      prevText: 'Página anterior',
      nextText: 'Próxima página',
      total: 'Total',
      item: 'item',
      items: 'itens',
      pageSize: '/ página',
      goto: 'Ir para',
      pageText: '',
      prev5Text: '5 Páginas anteriores',
      next5Text: 'Próximas 5 Páginas'
    },
    table: {
      emptyText: 'Sem dados'
    }
  }
}
