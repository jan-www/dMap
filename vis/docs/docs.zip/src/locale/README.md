# Internationalization

The default language is English (en-US). The internationalization of `AT-UI` is based on [vue-i18n](https://github.com/kazupon/vue-i18n), which makes it eaiser to switch between multiple languages.

Put the file of language into the `lang` folder.
